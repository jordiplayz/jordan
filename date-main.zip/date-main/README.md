# date
that stupid dtae thing in C (Windows)
